		<footer>

			<h1>En savoir plus ...</h1>
			<div class="ensavoirplus">

				<div class="apropos">
					<h3>À propos de nous</h3>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione, quidem recusandae explicabo veniam voluptatem voluptatum reprehenderit dignissimos ipsum magnam accusantium, dolores odio, dolorem provident sapiente consequuntur harum eaque veritatis? Eveniet.</p>
				</div>

				<div class="apropos">
					<h3>À propos de vos données</h3>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione, quidem recusandae explicabo veniam voluptatem voluptatum reprehenderit dignissimos ipsum magnam accusantium, dolores odio, dolorem provident sapiente consequuntur harum eaque veritatis? Eveniet.</p>
				</div>

				<div class="apropos">
					<h3>À propos de la fiabilité de vos futures rencontres</h3>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione, quidem recusandae explicabo veniam voluptatem voluptatum reprehenderit dignissimos ipsum magnam accusantium, dolores odio, dolorem provident sapiente consequuntur harum eaque veritatis? Eveniet.</p>
				</div>

			</div>

			<p class="contact">Projet réalisé par Mathis Huriez et Quentin Lacombe | &copy; 2021, Doux Deule Inc.</p>
		</footer>
	</body>
</html>